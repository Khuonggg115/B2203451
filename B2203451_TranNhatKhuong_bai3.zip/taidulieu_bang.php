<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);

}
//tao chuoi luu cau lenh sql
$sql = "SELECT * FROM student";
//thuc thi cau lenh sql va dua doi tuong vao $result
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
    // while($row = $result->fetch_assoc()) {
    //     echo "id: " . $row["id"]. " - Hoten: " . $row["fullname"]. " " .
    //     $row["email"].' ngaysinh: '.$row['Birthday']. "<br>";
    //     }
    //     echo '<br>';
    //     echo '<br>';
    //     //xoa ket qua cu tu o tren
    //     $result -> free_result();
    
    
    /*
    echo "<h3>Cách 4: Dùng fetch_row()</h3>";
    
    while ($row = $result->fetch_row()) 
    {
        echo "ID: " . $row[0] . " - Name: " . $row[1] . " - Email: " . $row[2] . "<br>";
    }

    */
    echo "<h3>Cách 5: Dùng fetch_array() (MYSQLI_ASSOC)</h3>";
    while ($row = $result->fetch_array(MYSQLI_ASSOC)) 
    {
        echo "ID: " . $row['id'] . " - Name: " . $row['fullname'] . " - Email: " . $row['email'] . "-" .$row['Birthday']. "<br>";
    }

    // echo "<h3>Cách 6: Dùng fetch_object()</h3>";
    // while ($row = $result->fetch_object()) 
    // {
    //     echo "ID: " . $row->id . " - Name: " . $row->fullname . " - Email: " . $row->email . "<br>";
    // }


}

$conn->close();