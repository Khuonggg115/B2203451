<?php $__env->startSection('content'); ?>

    <?php if(Session::has('success_message')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <?php echo session('success_message'); ?>


            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card text-bg-theme">

        <div class="card-header d-flex justify-content-between align-items-center p-3">
            <h4 class="m-0">Students</h4>
            <div>
                <a href="<?php echo e(route('students.student.create')); ?>" class="btn btn-secondary" title="Create New Student">
                    <span class="fa-solid fa-plus" aria-hidden="true"></span>
                </a>
            </div>
        </div>
        
        <?php if(count($students) == 0): ?>
            <div class="card-body text-center">
                <h4>No Students Available.</h4>
            </div>
        <?php else: ?>
        <div class="card-body p-0">
            <div class="table-responsive">

                <table class="table table-striped ">
                    <thead>
                        <tr>
                            <th>Fullname</th>
                            <th>Email</th>
                            <th>Birthday</th>
                            <th>Reg Date</th>
                            <th>Major</th>

                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="align-middle"><?php echo e($student->fullname); ?></td>
                            <td class="align-middle"><?php echo e($student->email); ?></td>
                            <td class="align-middle"><?php echo e($student->Birthday); ?></td>
                            <td class="align-middle"><?php echo e($student->reg_date); ?></td>
                            <td class="align-middle"><?php echo e(optional($student->major)->name_major); ?></td>

                            <td class="text-end">

                                <form method="POST" action="<?php echo route('students.student.destroy', $student->id); ?>" accept-charset="UTF-8">
                                <input name="_method" value="DELETE" type="hidden">
                                <?php echo e(csrf_field()); ?>


                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="<?php echo e(route('students.student.show', $student->id )); ?>" class="btn btn-info" title="Show Student">
                                            <span class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></span>
                                        </a>
                                        <a href="<?php echo e(route('students.student.edit', $student->id )); ?>" class="btn btn-primary" title="Edit Student">
                                            <span class="fa-regular fa-pen-to-square" aria-hidden="true"></span>
                                        </a>

                                        <button type="submit" class="btn btn-danger" title="Delete Student" onclick="return confirm(&quot;Click Ok to delete Student.&quot;)">
                                            <span class="fa-regular fa-trash-can" aria-hidden="true"></span>
                                        </button>
                                    </div>

                                </form>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>

            <?php echo $students->links('pagination'); ?>

        </div>
        
        <?php endif; ?>
    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\buoi5\resources\views/students/index.blade.php ENDPATH**/ ?>