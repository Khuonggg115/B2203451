<html>
    <body>
        <h1>Laravel Quickstart</h1>

        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\buoi5\resources\views/layouts.blade.php ENDPATH**/ ?>