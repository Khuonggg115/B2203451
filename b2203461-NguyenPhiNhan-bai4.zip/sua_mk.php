<?php
session_start(); // Start session to check login status

// Redirect to login page if the user is not logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if (isset($_POST['submit'])) {
    $old_pass = $_POST['old_pass']; // Get the old password
    $new_pass = $_POST['new_pass']; // Get the new password
    $confirm_pass = $_POST['confirm_pass']; // Get the confirmation password

    // Validate that new password and confirmation password match
    if ($new_pass !== $confirm_pass) {
        echo "New password and confirmation do not match.";
    } else {
        // Get the email of the logged-in user
        $email = $_SESSION['email'];
        
        // Prepare and execute a query to get the hashed old password
        $stmt = $conn->prepare("SELECT password FROM customers WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $old_pass_hashed = $row['password'];

            // Verify the old password
            if (password_verify($old_pass, $old_pass_hashed)) {
                // Check that the new password is not the same as the old password
                if (password_verify($new_pass, $old_pass_hashed)) {
                    echo "New password cannot be the same as the old password.";
                } else {
                    // Hash the new password and update it in the database
                    $new_pass_hashed = password_hash($new_pass, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE customers SET password = ? WHERE email = ?");
                    $stmt->bind_param("ss", $new_pass_hashed, $email);
                    
                    if ($stmt->execute()) {
                        echo "Password updated successfully.";
                    } else {
                        echo "Error: " . $stmt->error; // Detailed error message
                    }
                }
            } else {
                echo "Old password is incorrect.";
            }
        } else {
            echo "Account not found.";
        }
        $stmt->close();
    }
}

$conn->close();
?>
