<!DOCTYPE html>
<html>
<head>
    <title>Đổi Mật Khẩu</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <div class="w3-container w3-padding-16">
        <h2>Đổi Mật Khẩu</h2>
        <form action="sua_mk.php" method="post">
            <label for="old_pass">Mật khẩu cũ:</label><br>
            <input type="password" id="old_pass" name="old_pass" required><br><br>
            <label for="new_pass">Mật khẩu mới:</label><br>
            <input type="password" id="new_pass" name="new_pass" required><br><br>
            <label for="confirm_pass">Nhập lại mật khẩu mới:</label><br>
            <input type="password" id="confirm_pass" name="confirm_pass" required><br><br>
            <input type="submit" name="submit" value="Cập Nhật">
        </form>
    </div>
</body>
</html>
