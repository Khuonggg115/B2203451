<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// sql to create table
$sql = "CREATE TABLE `customers` (
`id` int(6) UNSIGNED NOT NULL,
`fullname` varchar(50) CHARACTER SET latin1 NOT NULL,
`email` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
`Birthday` date DEFAULT NULL,
`reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE
current_timestamp(),
`password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

if ($conn->query($sql) === TRUE) {
    echo "Table customers created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
$conn->close();
